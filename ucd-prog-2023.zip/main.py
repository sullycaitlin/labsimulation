import labs.lab5

labs.lab5.menu()